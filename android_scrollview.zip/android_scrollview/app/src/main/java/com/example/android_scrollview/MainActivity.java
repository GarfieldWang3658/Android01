package com.example.android_scrollview;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SeekBar.OnSeekBarChangeListener {
    private SeekBar seekBar;
    private TextView tv1;
    private TextView tv2;

    private TextView tv;
    private ScrollView scrollView;
    private Button up_btn;
    private Button down_btn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        tv =findViewById(R.id.content);
        tv.setText(getResources().getString(R.string.content));
        scrollView=findViewById(R.id.scroll);
        up_btn=findViewById(R.id.up);
        down_btn=findViewById(R.id.down);
        up_btn.setOnClickListener(this);
        down_btn.setOnClickListener(this);
        seekBar=findViewById(R.id.seekbar);
        seekBar.setOnSeekBarChangeListener(this);
        tv1=findViewById(R.id.tv1);
        tv2=findViewById(R.id.tv2);



        scrollView.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_UP:
                    {
                        break;
                    }
                    case MotionEvent.ACTION_DOWN:
                    {
                        break;
                    }
                    case MotionEvent.ACTION_MOVE:
                    {
                        //getScrollY() スライドーの距離
                        //getMeasuredHeight()
                        //getHeight()
                        if (scrollView.getScrollY()<=0){
                            Log.i("Main","一番上にスライドしました。");
                        }
                        //textviewの高さ＜＝
                        // スクリーニングの高さ＋SCROLLバースライドーの距離
                        //
                        if (scrollView.getChildAt(0).getMeasuredHeight()<=
                                scrollView.getHeight()+scrollView.getScrollY()){
                            Log.i("Main","一番下にスライドしました。");
                        tv.append(getResources().getString(R.string.content));

                        }
                        break;
                    }
                }

                return false;
            }
        });
    }

    @Override
    public void onClick(View v) {
            if (v.getId()==R.id.up)
            //scrollTo:以滚动位置启始位置开始计算
                //scrollBy:相对前一次位置，去滚动对应的距离。
            {scrollView.scrollBy(0,-50);}
            if(v.getId()==R.id.down)
            {scrollView.scrollBy(0,50);}


    }
    //数値変更する時に実装します。
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        tv1.setText("進捗調整中");
        tv2.setText("現在値"+progress);


    }
    //SEEKBARの移動を開始する時に実装します。
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        tv1.setText("スタート");


    }
    //SEEKBARの移動を止まる時に実装します
    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        tv1.setText("ストップ");

    }
}