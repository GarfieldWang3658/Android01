package com.example.android_scrollview;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Gallery;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.ViewSwitcher;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.navigation.NavigationBarView;

public class MainActivity2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener, ViewSwitcher.ViewFactory {
    private int[]res={R.drawable.aaa,R.drawable.bbb,R.drawable.ccc,R.drawable.ddd,R.drawable.eee,R.drawable.fff};

    private Gallery gallery;

//    ArrayAdapter<String>adapter;
//    SimpleAdapter adapter2;

    private ImageAdapter adapter;
    private ImageSwitcher is;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        gallery=findViewById(R.id.gallery);
        gallery.setAdapter(adapter);
        adapter=new ImageAdapter(res,this);
        gallery.setAdapter(adapter);
        gallery.setOnItemSelectedListener(this);
        is=findViewById(R.id.is);
        is.setFactory(this);








    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //image.setBackgroundResource(res[position%res.length]);
        is.setBackgroundResource(res[position%res.length]);


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public View makeView() {
        ImageView imageView=new ImageView(this);
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);

        return imageView;
    }
}