package com.example.android_viewpager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.List;

public class MyFragmentPagerAdapter extends FragmentPagerAdapter {
    private List<Fragment>fragmentList;
    private List<String>titleList;

    public MyFragmentPagerAdapter(@NonNull FragmentManager fm, List<android.app.Fragment> fragmentList, List<String> titleList) {
        super(fm);
        this.fragmentList = this.fragmentList;
        this.titleList= this.titleList;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return titleList.get(position);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentList.size();
    }

}
