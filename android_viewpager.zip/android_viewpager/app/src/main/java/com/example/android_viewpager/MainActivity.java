package com.example.android_viewpager;

import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.PagerTabStrip;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends FragmentActivity {
    private List<View>viewList;
    private ViewPager viewPager;

    private TabLayout tab;

    private List<String>titleList;
    private List<Fragment>fragmentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        viewList=new ArrayList<View>();
        View view1 = View.inflate(this, R.layout.view1, null);
        View view2 = View.inflate(this, R.layout.view2, null);
        View view3 = View.inflate(this, R.layout.view3, null);
        View view4 = View.inflate(this, R.layout.view4, null);
        viewList.add(view1);
        viewList.add(view2);
        viewList.add(view3);
        viewList.add(view4);

        //ViewPagerのページカードにタイトルを設定します。
        titleList =new ArrayList<>();
        titleList.add("ページ１");
        titleList.add("ページ２");
        titleList.add("ページ３");
        titleList.add("ページ４");

        //fragmentをvierpagerのデーター源として使います。
        fragmentList=new ArrayList<Fragment>();
        fragmentList.add(new Fragment1());
        fragmentList.add(new Fragment2());
        fragmentList.add(new Fragment3());
        fragmentList.add(new Fragment4());



        //pagerTabStripを設定します。
//        tab= findViewById(R.id.tab);
//        tab.setBackgroundColor(Color.YELLOW);
//        tab.setTextColor(Color.RED);
//        tab.setDrawFullUnderline(false);
//        tab.setTabIndicatorColor(Color.GREEN);
        tab=findViewById(R.id.tab);

        //ViewPagerを初期化します。
        viewPager=(ViewPager)findViewById(R.id.pager);


        //pageradpterをクリエートします
        MyPagerAdapter adapter = new MyPagerAdapter(viewList,titleList);

        //ViewPagerはアダプターを実装します。
        //viewPager.setAdapter(adapter);

        MyFragmentPagerAdapter myFragmentPagerAdapter=new MyFragmentPagerAdapter(getSupportFragmentManager(),fragmentList,titleList);
        viewPager.setAdapter(myFragmentPagerAdapter);



    }
}