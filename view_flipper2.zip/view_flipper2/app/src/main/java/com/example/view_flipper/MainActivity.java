package com.example.view_flipper;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ViewFlipper viewFlipper;
    private int[]resId={R.drawable.miso,R.drawable.syoyu,R.drawable.tonkotu};

    private float startX;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        viewFlipper = findViewById(R.id.flipper);

        //動的なローディングでViewFlipperに子Viewを加入します。

        for (int i= 0; i <resId.length ; i++) {
            viewFlipper.addView(getImagView(resId[i]));

        }

        viewFlipper.startFlipping();

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
            {
                startX=event.getX();
                break;
            }
            case MotionEvent.ACTION_MOVE:
            {
                if (event.getX()-startX>100){//右にスライドー
                    viewFlipper.showPrevious();//前のページを表示
                }else if (startX-event.getX()<100){//左にスライドー
                    viewFlipper.showNext();
                }

                break;
            }
            case MotionEvent.ACTION_UP:
            {
                break;
            }


        }
        return super.onTouchEvent(event);
    }

    private ImageView getImagView(int resId){
        ImageView imageView=new ImageView(this);
        imageView.setImageResource(resId);
        //imageView.setBackgroundResource(resId);
        return imageView;
    }

}